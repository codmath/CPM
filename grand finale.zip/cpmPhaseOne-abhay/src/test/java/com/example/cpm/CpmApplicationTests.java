package com.example.cpm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpmApplicationTests {

	@Test
	void contextLoads() {
	}

}
