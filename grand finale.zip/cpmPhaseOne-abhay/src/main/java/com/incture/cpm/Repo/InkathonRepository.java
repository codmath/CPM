package com.incture.cpm.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.incture.cpm.Entity.Inkathon;

public interface InkathonRepository extends JpaRepository<Inkathon,Long>{
    
}
