package com.incture.cpm.Exception;

public class InterviewerNotFoundException extends RuntimeException{
    public  InterviewerNotFoundException(String message){
        super(message);
    }
}
