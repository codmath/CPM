package com.incture.cpm.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.incture.cpm.Entity.CollegeTPO;

public interface CollegeRepository extends JpaRepository<CollegeTPO, Integer> {

     
} 
