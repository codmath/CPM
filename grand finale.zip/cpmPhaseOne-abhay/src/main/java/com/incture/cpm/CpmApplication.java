package com.incture.cpm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpmApplication {
	public static void main(String[] args) {
		SpringApplication.run(CpmApplication.class, args);
	}
}
