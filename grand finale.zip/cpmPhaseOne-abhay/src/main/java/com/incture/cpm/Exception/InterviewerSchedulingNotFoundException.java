package com.incture.cpm.Exception;

public class InterviewerSchedulingNotFoundException extends RuntimeException{
    public InterviewerSchedulingNotFoundException(String message){
        super(message);
    }
}
